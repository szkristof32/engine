/*     */ package de.matthiasmann.twl.utils;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Arrays;
/*     */ import java.util.zip.CRC32;
/*     */ import java.util.zip.Inflater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PNGDecoder
/*     */ {
/*     */   public enum Format
/*     */   {
/*  51 */     ALPHA(1, true),
/*  52 */     LUMINANCE(1, false),
/*  53 */     LUMINANCE_ALPHA(2, true),
/*  54 */     RGB(3, false),
/*  55 */     RGBA(4, true),
/*  56 */     BGRA(4, true),
/*  57 */     ABGR(4, true);
/*     */     
/*     */     final int numComponents;
/*     */     final boolean hasAlpha;
/*     */     
/*     */     Format(int numComponents, boolean hasAlpha) {
/*  63 */       this.numComponents = numComponents;
/*  64 */       this.hasAlpha = hasAlpha;
/*     */     }
/*     */     
/*     */     public int getNumComponents() {
/*  68 */       return this.numComponents;
/*     */     }
/*     */     
/*     */     public boolean isHasAlpha() {
/*  72 */       return this.hasAlpha;
/*     */     }
/*     */   }
/*     */   
/*  76 */   private static final byte[] SIGNATURE = new byte[] { -119, 80, 78, 71, 13, 10, 26, 10 };
/*     */   
/*     */   private static final int IHDR = 1229472850;
/*     */   
/*     */   private static final int PLTE = 1347179589;
/*     */   
/*     */   private static final int tRNS = 1951551059;
/*     */   
/*     */   private static final int IDAT = 1229209940;
/*     */   
/*     */   private static final int IEND = 1229278788;
/*     */   private static final byte COLOR_GREYSCALE = 0;
/*     */   private static final byte COLOR_TRUECOLOR = 2;
/*     */   private static final byte COLOR_INDEXED = 3;
/*     */   private static final byte COLOR_GREYALPHA = 4;
/*     */   private static final byte COLOR_TRUEALPHA = 6;
/*     */   private final InputStream input;
/*     */   private final CRC32 crc;
/*     */   private final byte[] buffer;
/*     */   private int chunkLength;
/*     */   private int chunkType;
/*     */   private int chunkRemaining;
/*     */   private int width;
/*     */   private int height;
/*     */   private int bitdepth;
/*     */   private int colorType;
/*     */   private int bytesPerPixel;
/*     */   private byte[] palette;
/*     */   private byte[] paletteA;
/*     */   private byte[] transPixel;
/*     */   
/*     */   public PNGDecoder(InputStream input) throws IOException {
/* 108 */     this.input = input;
/* 109 */     this.crc = new CRC32();
/* 110 */     this.buffer = new byte[4096];
/*     */     
/* 112 */     readFully(this.buffer, 0, SIGNATURE.length);
/* 113 */     if (!checkSignature(this.buffer)) {
/* 114 */       throw new IOException("Not a valid PNG file");
/*     */     }
/*     */     
/* 117 */     openChunk(1229472850);
/* 118 */     readIHDR();
/* 119 */     closeChunk();
/*     */     
/*     */     while (true) {
/* 122 */       openChunk();
/* 123 */       switch (this.chunkType) {
/*     */         case 1229209940:
/*     */           break;
/*     */         case 1347179589:
/* 127 */           readPLTE();
/*     */           break;
/*     */         case 1951551059:
/* 130 */           readtRNS();
/*     */           break;
/*     */       } 
/* 133 */       closeChunk();
/*     */     } 
/*     */     
/* 136 */     if (this.colorType == 3 && this.palette == null) {
/* 137 */       throw new IOException("Missing PLTE chunk");
/*     */     }
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 142 */     return this.height;
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 146 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAlphaChannel() {
/* 157 */     return (this.colorType == 6 || this.colorType == 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAlpha() {
/* 169 */     return (hasAlphaChannel() || this.paletteA != null || this.transPixel != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRGB() {
/* 174 */     return (this.colorType == 6 || this.colorType == 2 || this.colorType == 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void overwriteTRNS(byte r, byte g, byte b) {
/* 191 */     if (hasAlphaChannel()) {
/* 192 */       throw new UnsupportedOperationException("image has an alpha channel");
/*     */     }
/* 194 */     byte[] pal = this.palette;
/* 195 */     if (pal == null) {
/* 196 */       this.transPixel = new byte[] { 0, r, 0, g, 0, b };
/*     */     } else {
/* 198 */       this.paletteA = new byte[pal.length / 3];
/* 199 */       for (int i = 0, j = 0; i < pal.length; i += 3, j++) {
/* 200 */         if (pal[i] != r || pal[i + 1] != g || pal[i + 2] != b) {
/* 201 */           this.paletteA[j] = -1;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Format decideTextureFormat(Format fmt) {
/* 215 */     switch (this.colorType) {
/*     */       case 2:
/* 217 */         switch (fmt) { case ABGR:
/*     */           case RGBA:
/*     */           case BGRA:
/*     */           case RGB:
/* 221 */             return fmt; }
/* 222 */          return Format.RGB;
/*     */       
/*     */       case 6:
/* 225 */         switch (fmt) { case ABGR:
/*     */           case RGBA:
/*     */           case BGRA:
/*     */           case RGB:
/* 229 */             return fmt; }
/* 230 */          return Format.RGBA;
/*     */       
/*     */       case 0:
/* 233 */         switch (fmt) { case LUMINANCE:
/*     */           case ALPHA:
/* 235 */             return fmt; }
/* 236 */          return Format.LUMINANCE;
/*     */       
/*     */       case 4:
/* 239 */         return Format.LUMINANCE_ALPHA;
/*     */       case 3:
/* 241 */         switch (fmt) { case ABGR:
/*     */           case RGBA:
/*     */           case BGRA:
/* 244 */             return fmt; }
/* 245 */          return Format.RGBA;
/*     */     } 
/*     */     
/* 248 */     throw new UnsupportedOperationException("Not yet implemented");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decode(ByteBuffer buffer, int stride, Format fmt) throws IOException {
/* 265 */     int offset = buffer.position();
/* 266 */     int lineSize = (this.width * this.bitdepth + 7) / 8 * this.bytesPerPixel;
/* 267 */     byte[] curLine = new byte[lineSize + 1];
/* 268 */     byte[] prevLine = new byte[lineSize + 1];
/* 269 */     byte[] palLine = (this.bitdepth < 8) ? new byte[this.width + 1] : null;
/*     */     
/* 271 */     Inflater inflater = new Inflater();
/*     */     try {
/* 273 */       for (int y = 0; y < this.height; y++) {
/* 274 */         readChunkUnzip(inflater, curLine, 0, curLine.length);
/* 275 */         unfilter(curLine, prevLine);
/*     */         
/* 277 */         buffer.position(offset + y * stride);
/*     */         
/* 279 */         switch (this.colorType) {
/*     */           case 2:
/* 281 */             switch (fmt) { case ABGR:
/* 282 */                 copyRGBtoABGR(buffer, curLine); break;
/* 283 */               case RGBA: copyRGBtoRGBA(buffer, curLine); break;
/* 284 */               case BGRA: copyRGBtoBGRA(buffer, curLine); break;
/* 285 */               case RGB: copy(buffer, curLine); break; }
/* 286 */              throw new UnsupportedOperationException("Unsupported format for this image");
/*     */ 
/*     */           
/*     */           case 6:
/* 290 */             switch (fmt) { case ABGR:
/* 291 */                 copyRGBAtoABGR(buffer, curLine); break;
/* 292 */               case RGBA: copy(buffer, curLine); break;
/* 293 */               case BGRA: copyRGBAtoBGRA(buffer, curLine); break;
/* 294 */               case RGB: copyRGBAtoRGB(buffer, curLine); break; }
/* 295 */              throw new UnsupportedOperationException("Unsupported format for this image");
/*     */ 
/*     */           
/*     */           case 0:
/* 299 */             switch (fmt) { case LUMINANCE:
/*     */               case ALPHA:
/* 301 */                 copy(buffer, curLine); break; }
/* 302 */              throw new UnsupportedOperationException("Unsupported format for this image");
/*     */ 
/*     */           
/*     */           case 4:
/* 306 */             switch (fmt) { case LUMINANCE_ALPHA:
/* 307 */                 copy(buffer, curLine); break; }
/* 308 */              throw new UnsupportedOperationException("Unsupported format for this image");
/*     */ 
/*     */           
/*     */           case 3:
/* 312 */             switch (this.bitdepth) { case 8:
/* 313 */                 palLine = curLine; break;
/* 314 */               case 4: expand4(curLine, palLine); break;
/* 315 */               case 2: expand2(curLine, palLine); break;
/* 316 */               case 1: expand1(curLine, palLine); break;
/* 317 */               default: throw new UnsupportedOperationException("Unsupported bitdepth for this image"); }
/*     */             
/* 319 */             switch (fmt) { case ABGR:
/* 320 */                 copyPALtoABGR(buffer, palLine); break;
/* 321 */               case RGBA: copyPALtoRGBA(buffer, palLine); break;
/* 322 */               case BGRA: copyPALtoBGRA(buffer, palLine); break; }
/* 323 */              throw new UnsupportedOperationException("Unsupported format for this image");
/*     */ 
/*     */           
/*     */           default:
/* 327 */             throw new UnsupportedOperationException("Not yet implemented");
/*     */         } 
/*     */         
/* 330 */         byte[] tmp = curLine;
/* 331 */         curLine = prevLine;
/* 332 */         prevLine = tmp;
/*     */       } 
/*     */     } finally {
/* 335 */       inflater.end();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeFlipped(ByteBuffer buffer, int stride, Format fmt) throws IOException {
/* 352 */     if (stride <= 0) {
/* 353 */       throw new IllegalArgumentException("stride");
/*     */     }
/* 355 */     int pos = buffer.position();
/* 356 */     int posDelta = (this.height - 1) * stride;
/* 357 */     buffer.position(pos + posDelta);
/* 358 */     decode(buffer, -stride, fmt);
/* 359 */     buffer.position(buffer.position() + posDelta);
/*     */   }
/*     */   
/*     */   private void copy(ByteBuffer buffer, byte[] curLine) {
/* 363 */     buffer.put(curLine, 1, curLine.length - 1);
/*     */   }
/*     */   
/*     */   private void copyRGBtoABGR(ByteBuffer buffer, byte[] curLine) {
/* 367 */     if (this.transPixel != null) {
/* 368 */       byte tr = this.transPixel[1];
/* 369 */       byte tg = this.transPixel[3];
/* 370 */       byte tb = this.transPixel[5];
/* 371 */       for (int i = 1, n = curLine.length; i < n; i += 3) {
/* 372 */         byte r = curLine[i];
/* 373 */         byte g = curLine[i + 1];
/* 374 */         byte b = curLine[i + 2];
/* 375 */         byte a = -1;
/* 376 */         if (r == tr && g == tg && b == tb) {
/* 377 */           a = 0;
/*     */         }
/* 379 */         buffer.put(a).put(b).put(g).put(r);
/*     */       } 
/*     */     } else {
/* 382 */       for (int i = 1, n = curLine.length; i < n; i += 3) {
/* 383 */         buffer.put((byte)-1).put(curLine[i + 2]).put(curLine[i + 1]).put(curLine[i]);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void copyRGBtoRGBA(ByteBuffer buffer, byte[] curLine) {
/* 389 */     if (this.transPixel != null) {
/* 390 */       byte tr = this.transPixel[1];
/* 391 */       byte tg = this.transPixel[3];
/* 392 */       byte tb = this.transPixel[5];
/* 393 */       for (int i = 1, n = curLine.length; i < n; i += 3) {
/* 394 */         byte r = curLine[i];
/* 395 */         byte g = curLine[i + 1];
/* 396 */         byte b = curLine[i + 2];
/* 397 */         byte a = -1;
/* 398 */         if (r == tr && g == tg && b == tb) {
/* 399 */           a = 0;
/*     */         }
/* 401 */         buffer.put(r).put(g).put(b).put(a);
/*     */       } 
/*     */     } else {
/* 404 */       for (int i = 1, n = curLine.length; i < n; i += 3) {
/* 405 */         buffer.put(curLine[i]).put(curLine[i + 1]).put(curLine[i + 2]).put((byte)-1);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void copyRGBtoBGRA(ByteBuffer buffer, byte[] curLine) {
/* 411 */     if (this.transPixel != null) {
/* 412 */       byte tr = this.transPixel[1];
/* 413 */       byte tg = this.transPixel[3];
/* 414 */       byte tb = this.transPixel[5];
/* 415 */       for (int i = 1, n = curLine.length; i < n; i += 3) {
/* 416 */         byte r = curLine[i];
/* 417 */         byte g = curLine[i + 1];
/* 418 */         byte b = curLine[i + 2];
/* 419 */         byte a = -1;
/* 420 */         if (r == tr && g == tg && b == tb) {
/* 421 */           a = 0;
/*     */         }
/* 423 */         buffer.put(b).put(g).put(r).put(a);
/*     */       } 
/*     */     } else {
/* 426 */       for (int i = 1, n = curLine.length; i < n; i += 3) {
/* 427 */         buffer.put(curLine[i + 2]).put(curLine[i + 1]).put(curLine[i]).put((byte)-1);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void copyRGBAtoABGR(ByteBuffer buffer, byte[] curLine) {
/* 433 */     for (int i = 1, n = curLine.length; i < n; i += 4) {
/* 434 */       buffer.put(curLine[i + 3]).put(curLine[i + 2]).put(curLine[i + 1]).put(curLine[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   private void copyRGBAtoBGRA(ByteBuffer buffer, byte[] curLine) {
/* 439 */     for (int i = 1, n = curLine.length; i < n; i += 4) {
/* 440 */       buffer.put(curLine[i + 2]).put(curLine[i + 1]).put(curLine[i]).put(curLine[i + 3]);
/*     */     }
/*     */   }
/*     */   
/*     */   private void copyRGBAtoRGB(ByteBuffer buffer, byte[] curLine) {
/* 445 */     for (int i = 1, n = curLine.length; i < n; i += 4) {
/* 446 */       buffer.put(curLine[i]).put(curLine[i + 1]).put(curLine[i + 2]);
/*     */     }
/*     */   }
/*     */   
/*     */   private void copyPALtoABGR(ByteBuffer buffer, byte[] curLine) {
/* 451 */     if (this.paletteA != null) {
/* 452 */       for (int i = 1, n = curLine.length; i < n; i++) {
/* 453 */         int idx = curLine[i] & 0xFF;
/* 454 */         byte r = this.palette[idx * 3 + 0];
/* 455 */         byte g = this.palette[idx * 3 + 1];
/* 456 */         byte b = this.palette[idx * 3 + 2];
/* 457 */         byte a = this.paletteA[idx];
/* 458 */         buffer.put(a).put(b).put(g).put(r);
/*     */       } 
/*     */     } else {
/* 461 */       for (int i = 1, n = curLine.length; i < n; i++) {
/* 462 */         int idx = curLine[i] & 0xFF;
/* 463 */         byte r = this.palette[idx * 3 + 0];
/* 464 */         byte g = this.palette[idx * 3 + 1];
/* 465 */         byte b = this.palette[idx * 3 + 2];
/* 466 */         byte a = -1;
/* 467 */         buffer.put(a).put(b).put(g).put(r);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void copyPALtoRGBA(ByteBuffer buffer, byte[] curLine) {
/* 473 */     if (this.paletteA != null) {
/* 474 */       for (int i = 1, n = curLine.length; i < n; i++) {
/* 475 */         int idx = curLine[i] & 0xFF;
/* 476 */         byte r = this.palette[idx * 3 + 0];
/* 477 */         byte g = this.palette[idx * 3 + 1];
/* 478 */         byte b = this.palette[idx * 3 + 2];
/* 479 */         byte a = this.paletteA[idx];
/* 480 */         buffer.put(r).put(g).put(b).put(a);
/*     */       } 
/*     */     } else {
/* 483 */       for (int i = 1, n = curLine.length; i < n; i++) {
/* 484 */         int idx = curLine[i] & 0xFF;
/* 485 */         byte r = this.palette[idx * 3 + 0];
/* 486 */         byte g = this.palette[idx * 3 + 1];
/* 487 */         byte b = this.palette[idx * 3 + 2];
/* 488 */         byte a = -1;
/* 489 */         buffer.put(r).put(g).put(b).put(a);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void copyPALtoBGRA(ByteBuffer buffer, byte[] curLine) {
/* 495 */     if (this.paletteA != null) {
/* 496 */       for (int i = 1, n = curLine.length; i < n; i++) {
/* 497 */         int idx = curLine[i] & 0xFF;
/* 498 */         byte r = this.palette[idx * 3 + 0];
/* 499 */         byte g = this.palette[idx * 3 + 1];
/* 500 */         byte b = this.palette[idx * 3 + 2];
/* 501 */         byte a = this.paletteA[idx];
/* 502 */         buffer.put(b).put(g).put(r).put(a);
/*     */       } 
/*     */     } else {
/* 505 */       for (int i = 1, n = curLine.length; i < n; i++) {
/* 506 */         int idx = curLine[i] & 0xFF;
/* 507 */         byte r = this.palette[idx * 3 + 0];
/* 508 */         byte g = this.palette[idx * 3 + 1];
/* 509 */         byte b = this.palette[idx * 3 + 2];
/* 510 */         byte a = -1;
/* 511 */         buffer.put(b).put(g).put(r).put(a);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void expand4(byte[] src, byte[] dst) {
/* 517 */     for (int i = 1, n = dst.length; i < n; i += 2) {
/* 518 */       int val = src[1 + (i >> 1)] & 0xFF;
/* 519 */       switch (n - i) { default:
/* 520 */           dst[i + 1] = (byte)(val & 0xF); break;
/* 521 */         case 1: break; }  dst[i] = (byte)(val >> 4);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void expand2(byte[] src, byte[] dst) {
/* 527 */     for (int i = 1, n = dst.length; i < n; i += 4) {
/* 528 */       int val = src[1 + (i >> 2)] & 0xFF;
/* 529 */       switch (n - i) { default:
/* 530 */           dst[i + 3] = (byte)(val & 0x3);
/* 531 */         case 3: dst[i + 2] = (byte)(val >> 2 & 0x3);
/* 532 */         case 2: dst[i + 1] = (byte)(val >> 4 & 0x3); break;
/* 533 */         case 1: break; }  dst[i] = (byte)(val >> 6);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void expand1(byte[] src, byte[] dst) {
/* 539 */     for (int i = 1, n = dst.length; i < n; i += 8) {
/* 540 */       int val = src[1 + (i >> 3)] & 0xFF;
/* 541 */       switch (n - i) { default:
/* 542 */           dst[i + 7] = (byte)(val & 0x1);
/* 543 */         case 7: dst[i + 6] = (byte)(val >> 1 & 0x1);
/* 544 */         case 6: dst[i + 5] = (byte)(val >> 2 & 0x1);
/* 545 */         case 5: dst[i + 4] = (byte)(val >> 3 & 0x1);
/* 546 */         case 4: dst[i + 3] = (byte)(val >> 4 & 0x1);
/* 547 */         case 3: dst[i + 2] = (byte)(val >> 5 & 0x1);
/* 548 */         case 2: dst[i + 1] = (byte)(val >> 6 & 0x1); break;
/* 549 */         case 1: break; }  dst[i] = (byte)(val >> 7);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void unfilter(byte[] curLine, byte[] prevLine) throws IOException {
/* 555 */     switch (curLine[0]) {
/*     */       case 0:
/*     */         return;
/*     */       case 1:
/* 559 */         unfilterSub(curLine);
/*     */       
/*     */       case 2:
/* 562 */         unfilterUp(curLine, prevLine);
/*     */       
/*     */       case 3:
/* 565 */         unfilterAverage(curLine, prevLine);
/*     */       
/*     */       case 4:
/* 568 */         unfilterPaeth(curLine, prevLine);
/*     */     } 
/*     */     
/* 571 */     throw new IOException("invalide filter type in scanline: " + curLine[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   private void unfilterSub(byte[] curLine) {
/* 576 */     int bpp = this.bytesPerPixel;
/* 577 */     for (int i = bpp + 1, n = curLine.length; i < n; i++) {
/* 578 */       curLine[i] = (byte)(curLine[i] + curLine[i - bpp]);
/*     */     }
/*     */   }
/*     */   
/*     */   private void unfilterUp(byte[] curLine, byte[] prevLine) {
/* 583 */     int bpp = this.bytesPerPixel;
/* 584 */     for (int i = 1, n = curLine.length; i < n; i++) {
/* 585 */       curLine[i] = (byte)(curLine[i] + prevLine[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   private void unfilterAverage(byte[] curLine, byte[] prevLine) {
/* 590 */     int bpp = this.bytesPerPixel;
/*     */     
/*     */     int i;
/* 593 */     for (i = 1; i <= bpp; i++) {
/* 594 */       curLine[i] = (byte)(curLine[i] + (byte)((prevLine[i] & 0xFF) >>> 1));
/*     */     }
/* 596 */     for (int n = curLine.length; i < n; i++) {
/* 597 */       curLine[i] = (byte)(curLine[i] + (byte)((prevLine[i] & 0xFF) + (curLine[i - bpp] & 0xFF) >>> 1));
/*     */     }
/*     */   }
/*     */   
/*     */   private void unfilterPaeth(byte[] curLine, byte[] prevLine) {
/* 602 */     int bpp = this.bytesPerPixel;
/*     */     
/*     */     int i;
/* 605 */     for (i = 1; i <= bpp; i++) {
/* 606 */       curLine[i] = (byte)(curLine[i] + prevLine[i]);
/*     */     }
/* 608 */     for (int n = curLine.length; i < n; i++) {
/* 609 */       int a = curLine[i - bpp] & 0xFF;
/* 610 */       int b = prevLine[i] & 0xFF;
/* 611 */       int c = prevLine[i - bpp] & 0xFF;
/* 612 */       int p = a + b - c;
/* 613 */       int pa = p - a; if (pa < 0) pa = -pa; 
/* 614 */       int pb = p - b; if (pb < 0) pb = -pb; 
/* 615 */       int pc = p - c; if (pc < 0) pc = -pc; 
/* 616 */       if (pa <= pb && pa <= pc) {
/* 617 */         c = a;
/* 618 */       } else if (pb <= pc) {
/* 619 */         c = b;
/* 620 */       }  curLine[i] = (byte)(curLine[i] + (byte)c);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void readIHDR() throws IOException {
/* 625 */     checkChunkLength(13);
/* 626 */     readChunk(this.buffer, 0, 13);
/* 627 */     this.width = readInt(this.buffer, 0);
/* 628 */     this.height = readInt(this.buffer, 4);
/* 629 */     this.bitdepth = this.buffer[8] & 0xFF;
/* 630 */     this.colorType = this.buffer[9] & 0xFF;
/*     */     
/* 632 */     switch (this.colorType) {
/*     */       case 0:
/* 634 */         if (this.bitdepth != 8) {
/* 635 */           throw new IOException("Unsupported bit depth: " + this.bitdepth);
/*     */         }
/* 637 */         this.bytesPerPixel = 1;
/*     */         break;
/*     */       case 4:
/* 640 */         if (this.bitdepth != 8) {
/* 641 */           throw new IOException("Unsupported bit depth: " + this.bitdepth);
/*     */         }
/* 643 */         this.bytesPerPixel = 2;
/*     */         break;
/*     */       case 2:
/* 646 */         if (this.bitdepth != 8) {
/* 647 */           throw new IOException("Unsupported bit depth: " + this.bitdepth);
/*     */         }
/* 649 */         this.bytesPerPixel = 3;
/*     */         break;
/*     */       case 6:
/* 652 */         if (this.bitdepth != 8) {
/* 653 */           throw new IOException("Unsupported bit depth: " + this.bitdepth);
/*     */         }
/* 655 */         this.bytesPerPixel = 4;
/*     */         break;
/*     */       case 3:
/* 658 */         switch (this.bitdepth) {
/*     */           case 1:
/*     */           case 2:
/*     */           case 4:
/*     */           case 8:
/* 663 */             this.bytesPerPixel = 1;
/*     */             break;
/*     */         } 
/* 666 */         throw new IOException("Unsupported bit depth: " + this.bitdepth);
/*     */ 
/*     */       
/*     */       default:
/* 670 */         throw new IOException("unsupported color format: " + this.colorType);
/*     */     } 
/*     */     
/* 673 */     if (this.buffer[10] != 0) {
/* 674 */       throw new IOException("unsupported compression method");
/*     */     }
/* 676 */     if (this.buffer[11] != 0) {
/* 677 */       throw new IOException("unsupported filtering method");
/*     */     }
/* 679 */     if (this.buffer[12] != 0) {
/* 680 */       throw new IOException("unsupported interlace method");
/*     */     }
/*     */   }
/*     */   
/*     */   private void readPLTE() throws IOException {
/* 685 */     int paletteEntries = this.chunkLength / 3;
/* 686 */     if (paletteEntries < 1 || paletteEntries > 256 || this.chunkLength % 3 != 0) {
/* 687 */       throw new IOException("PLTE chunk has wrong length");
/*     */     }
/* 689 */     this.palette = new byte[paletteEntries * 3];
/* 690 */     readChunk(this.palette, 0, this.palette.length);
/*     */   }
/*     */   
/*     */   private void readtRNS() throws IOException {
/* 694 */     switch (this.colorType) {
/*     */       case 0:
/* 696 */         checkChunkLength(2);
/* 697 */         this.transPixel = new byte[2];
/* 698 */         readChunk(this.transPixel, 0, 2);
/*     */         break;
/*     */       case 2:
/* 701 */         checkChunkLength(6);
/* 702 */         this.transPixel = new byte[6];
/* 703 */         readChunk(this.transPixel, 0, 6);
/*     */         break;
/*     */       case 3:
/* 706 */         if (this.palette == null) {
/* 707 */           throw new IOException("tRNS chunk without PLTE chunk");
/*     */         }
/* 709 */         this.paletteA = new byte[this.palette.length / 3];
/* 710 */         Arrays.fill(this.paletteA, (byte)-1);
/* 711 */         readChunk(this.paletteA, 0, this.paletteA.length);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void closeChunk() throws IOException {
/* 719 */     if (this.chunkRemaining > 0) {
/*     */       
/* 721 */       skip((this.chunkRemaining + 4));
/*     */     } else {
/* 723 */       readFully(this.buffer, 0, 4);
/* 724 */       int expectedCrc = readInt(this.buffer, 0);
/* 725 */       int computedCrc = (int)this.crc.getValue();
/* 726 */       if (computedCrc != expectedCrc) {
/* 727 */         throw new IOException("Invalid CRC");
/*     */       }
/*     */     } 
/* 730 */     this.chunkRemaining = 0;
/* 731 */     this.chunkLength = 0;
/* 732 */     this.chunkType = 0;
/*     */   }
/*     */   
/*     */   private void openChunk() throws IOException {
/* 736 */     readFully(this.buffer, 0, 8);
/* 737 */     this.chunkLength = readInt(this.buffer, 0);
/* 738 */     this.chunkType = readInt(this.buffer, 4);
/* 739 */     this.chunkRemaining = this.chunkLength;
/* 740 */     this.crc.reset();
/* 741 */     this.crc.update(this.buffer, 4, 4);
/*     */   }
/*     */   
/*     */   private void openChunk(int expected) throws IOException {
/* 745 */     openChunk();
/* 746 */     if (this.chunkType != expected) {
/* 747 */       throw new IOException("Expected chunk: " + Integer.toHexString(expected));
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkChunkLength(int expected) throws IOException {
/* 752 */     if (this.chunkLength != expected) {
/* 753 */       throw new IOException("Chunk has wrong size");
/*     */     }
/*     */   }
/*     */   
/*     */   private int readChunk(byte[] buffer, int offset, int length) throws IOException {
/* 758 */     if (length > this.chunkRemaining) {
/* 759 */       length = this.chunkRemaining;
/*     */     }
/* 761 */     readFully(buffer, offset, length);
/* 762 */     this.crc.update(buffer, offset, length);
/* 763 */     this.chunkRemaining -= length;
/* 764 */     return length;
/*     */   }
/*     */   
/*     */   private void refillInflater(Inflater inflater) throws IOException {
/* 768 */     while (this.chunkRemaining == 0) {
/* 769 */       closeChunk();
/* 770 */       openChunk(1229209940);
/*     */     } 
/* 772 */     int read = readChunk(this.buffer, 0, this.buffer.length);
/* 773 */     inflater.setInput(this.buffer, 0, read);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readChunkUnzip(Inflater inflater, byte[] buffer, int offset, int length) throws IOException {
/*     */     // Byte code:
/*     */     //   0: getstatic de/matthiasmann/twl/utils/PNGDecoder.$assertionsDisabled : Z
/*     */     //   3: ifne -> 22
/*     */     //   6: aload_2
/*     */     //   7: aload_0
/*     */     //   8: getfield buffer : [B
/*     */     //   11: if_acmpne -> 22
/*     */     //   14: new java/lang/AssertionError
/*     */     //   17: dup
/*     */     //   18: invokespecial <init> : ()V
/*     */     //   21: athrow
/*     */     //   22: aload_1
/*     */     //   23: aload_2
/*     */     //   24: iload_3
/*     */     //   25: iload #4
/*     */     //   27: invokevirtual inflate : ([BII)I
/*     */     //   30: istore #5
/*     */     //   32: iload #5
/*     */     //   34: ifgt -> 100
/*     */     //   37: aload_1
/*     */     //   38: invokevirtual finished : ()Z
/*     */     //   41: ifeq -> 52
/*     */     //   44: new java/io/EOFException
/*     */     //   47: dup
/*     */     //   48: invokespecial <init> : ()V
/*     */     //   51: athrow
/*     */     //   52: aload_1
/*     */     //   53: invokevirtual needsInput : ()Z
/*     */     //   56: ifeq -> 67
/*     */     //   59: aload_0
/*     */     //   60: aload_1
/*     */     //   61: invokespecial refillInflater : (Ljava/util/zip/Inflater;)V
/*     */     //   64: goto -> 112
/*     */     //   67: new java/io/IOException
/*     */     //   70: dup
/*     */     //   71: new java/lang/StringBuilder
/*     */     //   74: dup
/*     */     //   75: invokespecial <init> : ()V
/*     */     //   78: ldc 'Can't inflate '
/*     */     //   80: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   83: iload #4
/*     */     //   85: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   88: ldc ' bytes'
/*     */     //   90: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   93: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   96: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   99: athrow
/*     */     //   100: iload_3
/*     */     //   101: iload #5
/*     */     //   103: iadd
/*     */     //   104: istore_3
/*     */     //   105: iload #4
/*     */     //   107: iload #5
/*     */     //   109: isub
/*     */     //   110: istore #4
/*     */     //   112: iload #4
/*     */     //   114: ifgt -> 22
/*     */     //   117: goto -> 143
/*     */     //   120: astore #5
/*     */     //   122: new java/io/IOException
/*     */     //   125: dup
/*     */     //   126: ldc 'inflate error'
/*     */     //   128: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   131: aload #5
/*     */     //   133: invokevirtual initCause : (Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*     */     //   136: checkcast java/io/IOException
/*     */     //   139: checkcast java/io/IOException
/*     */     //   142: athrow
/*     */     //   143: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #777	-> 0
/*     */     //   #780	-> 22
/*     */     //   #781	-> 32
/*     */     //   #782	-> 37
/*     */     //   #783	-> 44
/*     */     //   #785	-> 52
/*     */     //   #786	-> 59
/*     */     //   #788	-> 67
/*     */     //   #791	-> 100
/*     */     //   #792	-> 105
/*     */     //   #794	-> 112
/*     */     //   #797	-> 117
/*     */     //   #795	-> 120
/*     */     //   #796	-> 122
/*     */     //   #798	-> 143
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   32	80	5	read	I
/*     */     //   122	21	5	ex	Ljava/util/zip/DataFormatException;
/*     */     //   0	144	0	this	Lde/matthiasmann/twl/utils/PNGDecoder;
/*     */     //   0	144	1	inflater	Ljava/util/zip/Inflater;
/*     */     //   0	144	2	buffer	[B
/*     */     //   0	144	3	offset	I
/*     */     //   0	144	4	length	I
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   22	117	120	java/util/zip/DataFormatException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readFully(byte[] buffer, int offset, int length) throws IOException {
/*     */     do {
/* 802 */       int read = this.input.read(buffer, offset, length);
/* 803 */       if (read < 0) {
/* 804 */         throw new EOFException();
/*     */       }
/* 806 */       offset += read;
/* 807 */       length -= read;
/* 808 */     } while (length > 0);
/*     */   }
/*     */   
/*     */   private int readInt(byte[] buffer, int offset) {
/* 812 */     return buffer[offset] << 24 | (buffer[offset + 1] & 0xFF) << 16 | (buffer[offset + 2] & 0xFF) << 8 | buffer[offset + 3] & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void skip(long amount) throws IOException {
/* 820 */     while (amount > 0L) {
/* 821 */       long skipped = this.input.skip(amount);
/* 822 */       if (skipped < 0L) {
/* 823 */         throw new EOFException();
/*     */       }
/* 825 */       amount -= skipped;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean checkSignature(byte[] buffer) {
/* 830 */     for (int i = 0; i < SIGNATURE.length; i++) {
/* 831 */       if (buffer[i] != SIGNATURE[i]) {
/* 832 */         return false;
/*     */       }
/*     */     } 
/* 835 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Kristóf\Programozás\Rebellion\lib\jar\PNGDecoder.jar!\de\matthiasmann\tw\\utils\PNGDecoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */